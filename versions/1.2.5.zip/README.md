# Browsercraft

This is a proof of concept of Minecraft running unmodified in the browser, using [CheerpJ](https://labs.leaningtech.com/cheerpj). 

See [the website](https://browsercraft.cheerpj.com) for a live demo and more information.
