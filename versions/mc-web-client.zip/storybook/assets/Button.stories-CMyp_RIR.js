import{B as n}from"./Button-D8F4WmjU.js";import"./jsx-runtime-BXiUAcbA.js";import"./index-yBjzXJbu.js";import"./index-B_ALIsCe.js";import"./SharedHudVars-BSL9pCCC.js";import"./PixelartIcon-Bmb-JS3z.js";const m={component:n},r={args:{label:"Hello!",icon:"pixelarticons:lock-open",inScreen:!1}};var o,e,a;r.parameters={...r.parameters,docs:{...(o=r.parameters)==null?void 0:o.docs,source:{originalSource:`{
  args: {
    label: 'Hello!',
    icon: 'pixelarticons:lock-open',
    inScreen: false
  }
}`,...(a=(e=r.parameters)==null?void 0:e.docs)==null?void 0:a.source}}};const d=["Primary"];export{r as Primary,d as __namedExportsOrder,m as default};
