import{g as r}from"./index-B_ALIsCe.js";import{r as t}from"./index-fNjTmf9T.js";var o=t();const m=r(o);export{m as R,o as r};
