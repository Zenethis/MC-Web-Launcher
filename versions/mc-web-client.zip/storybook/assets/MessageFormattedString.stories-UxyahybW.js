import{M as m}from"./MessageFormattedString-29dtJQfm.js";import"./jsx-runtime-BXiUAcbA.js";import"./index-yBjzXJbu.js";import"./index-B_ALIsCe.js";import"./index-N2c5PEsY.js";import"./index-fNjTmf9T.js";import"./client-8hqX0wC_.js";import"./errorBoundary-i09yzNIi.js";import"./Button-D8F4WmjU.js";import"./SharedHudVars-BSL9pCCC.js";import"./PixelartIcon-Bmb-JS3z.js";import"./useScrollBehavior-D_95wFNL.js";import"./globalState-CnxBlE5b.js";import"./assert-Dix6_GPv.js";import"./Screen-CUAyKyoP.js";const k={component:m},r={args:{message:"§cYou died!",fallbackColor:"white"}};var o,t,e;r.parameters={...r.parameters,docs:{...(o=r.parameters)==null?void 0:o.docs,source:{originalSource:`{
  args: {
    // red text using minecraft styling symbol
    message: '\\u00A7cYou died!',
    fallbackColor: 'white'
  }
}`,...(e=(t=r.parameters)==null?void 0:t.docs)==null?void 0:e.source}}};const w=["Primary"];export{r as Primary,w as __namedExportsOrder,k as default};
