import{j as o,a as r}from"./jsx-runtime-BXiUAcbA.js";import{r as s}from"./index-B_ALIsCe.js";import{M as x}from"./MessageFormattedString-29dtJQfm.js";import"./index-yBjzXJbu.js";import"./index-N2c5PEsY.js";import"./index-fNjTmf9T.js";import"./client-8hqX0wC_.js";import"./errorBoundary-i09yzNIi.js";import"./Button-D8F4WmjU.js";import"./SharedHudVars-BSL9pCCC.js";import"./PixelartIcon-Bmb-JS3z.js";import"./useScrollBehavior-D_95wFNL.js";import"./globalState-CnxBlE5b.js";import"./assert-Dix6_GPv.js";import"./Screen-CUAyKyoP.js";const i=["pink","blue","red","green","yellow","purple","white"],n=[0,6,10,12,20],S=({bar:e})=>{const[p,m]=s.useState({}),[y,u]=s.useState({}),[_,f]=s.useState({}),[g,h]=s.useState({}),[v,B]=s.useState({});return s.useEffect(()=>{m(e._title??e.title),u(t=>({...t,backgroundPositionY:`-${i.indexOf(e._color)*10}px`})),f(t=>({...t,width:`${e._health*100}%`,backgroundPositionY:`-${i.indexOf(e._color)*10+5}px`})),h(t=>({...t,backgroundPositionY:`-${n.indexOf(e._dividers)*10+70}px`})),B(t=>({...t,width:`${e._health*100}%`,backgroundPositionY:`-${n.indexOf(e._dividers)*10+75}px`}))},[e]),o("div",{className:"bossbar-container",children:[r("div",{className:"bossbar-title",children:r(x,{message:p})}),o("div",{className:"bossbar",style:y,children:[r("div",{className:"fill",style:_}),r("div",{className:"fill",style:g}),r("div",{className:"fill",style:v})]})]})};try{BossBarOverlay.displayName="BossBarOverlay",BossBarOverlay.__docgenInfo={description:"",displayName:"BossBarOverlay",props:{bar:{defaultValue:null,description:"",name:"bar",required:!0,type:{name:"BossBarType"}}}}}catch{}const M={component:S},a={args:{bar:{entityUUID:"uuid",title:{text:"Boss",translate:"test"},health:100,dividers:2,color:"red",shouldDarkenSky:!1,isDragonBar:!1,createFog:!1,shouldCreateFog:!1,_title:{text:"Boss",translate:"entity.minecraft.ender_dragon"},_color:"red",_dividers:2,_health:100,lastUpdated:0}}};var l,d,c;a.parameters={...a.parameters,docs:{...(l=a.parameters)==null?void 0:l.docs,source:{originalSource:`{
  args: {
    bar: {
      entityUUID: 'uuid',
      title: {
        text: 'Boss',
        translate: 'test'
      } as ChatMessage & {
        text: string;
        translate: string;
      },
      health: 100,
      dividers: 2,
      color: 'red',
      shouldDarkenSky: false,
      isDragonBar: false,
      createFog: false,
      shouldCreateFog: false,
      _title: {
        text: 'Boss',
        translate: 'entity.minecraft.ender_dragon'
      },
      _color: 'red',
      _dividers: 2,
      _health: 100,
      lastUpdated: 0
    }
  }
}`,...(c=(d=a.parameters)==null?void 0:d.docs)==null?void 0:c.source}}};const T=["Primary"];export{a as Primary,T as __namedExportsOrder,M as default};
