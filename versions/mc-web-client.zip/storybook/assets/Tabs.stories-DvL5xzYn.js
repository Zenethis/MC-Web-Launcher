import{T as o}from"./Tabs-CQrpUpCg.js";import"./jsx-runtime-BXiUAcbA.js";import"./index-yBjzXJbu.js";import"./Button-D8F4WmjU.js";import"./index-B_ALIsCe.js";import"./SharedHudVars-BSL9pCCC.js";import"./PixelartIcon-Bmb-JS3z.js";const b={component:o,args:{tabs:["Tab 1","Tab 2"],activeTab:"Tab 1"}},r={args:{fullSize:!0}};var a,t,e;r.parameters={...r.parameters,docs:{...(a=r.parameters)==null?void 0:a.docs,source:{originalSource:`{
  args: {
    fullSize: true
  }
}`,...(e=(t=r.parameters)==null?void 0:t.docs)==null?void 0:e.source}}};const d=["Primary"];export{r as Primary,d as __namedExportsOrder,b as default};
