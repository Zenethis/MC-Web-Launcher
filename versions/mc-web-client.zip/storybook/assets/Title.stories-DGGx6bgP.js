import{j as u,a as t}from"./jsx-runtime-BXiUAcbA.js";import{r as s}from"./index-B_ALIsCe.js";import{M as l}from"./MessageFormattedString-29dtJQfm.js";import{A as p,m}from"./proxy-DY9yHEza.js";import"./index-yBjzXJbu.js";import"./index-N2c5PEsY.js";import"./index-fNjTmf9T.js";import"./client-8hqX0wC_.js";import"./errorBoundary-i09yzNIi.js";import"./Button-D8F4WmjU.js";import"./SharedHudVars-BSL9pCCC.js";import"./PixelartIcon-Bmb-JS3z.js";import"./useScrollBehavior-D_95wFNL.js";import"./globalState-CnxBlE5b.js";import"./assert-Dix6_GPv.js";import"./Screen-CUAyKyoP.js";const o=({title:d,subtitle:x,actionBar:b,transitionTimes:e,openTitle:r=!1,openActionBar:n=!1})=>{const[h,_]=s.useState(!1),i=.5,c=1;return s.useEffect(()=>{!h&&(r||n)&&_(!0)},[r,n]),u("div",{className:"title-container",children:[t(p,{children:r&&u(m.div,{initial:{opacity:0},animate:{opacity:1},exit:{opacity:0},transition:{duration:e!=null&&e.fadeIn?e.fadeIn/1e3:i,exit:{duration:e!=null&&e.fadeOut?e.fadeOut/1e3:c}},children:[t("h1",{className:"message-title",children:t(l,{message:d})}),t("h4",{className:"message-subtitle",children:t(l,{message:x})})]})}),t(p,{children:n&&t(m.div,{initial:{opacity:0},animate:{opacity:1},exit:{opacity:0},transition:{duration:e!=null&&e.fadeIn?e.fadeIn/1e3:i,exit:{duration:e!=null&&e.fadeOut?e.fadeOut/1e3:c}},children:t("div",{className:"message-action-bar",children:t(l,{message:b})})})})]})};try{o.displayName="Title",o.__docgenInfo={description:"",displayName:"Title",props:{title:{defaultValue:null,description:"",name:"title",required:!0,type:{name:"string | Record<string, any>"}},subtitle:{defaultValue:null,description:"",name:"subtitle",required:!0,type:{name:"string | Record<string, any>"}},actionBar:{defaultValue:null,description:"",name:"actionBar",required:!0,type:{name:"string | Record<string, any>"}},transitionTimes:{defaultValue:null,description:"",name:"transitionTimes",required:!0,type:{name:"AnimationTimes"}},openTitle:{defaultValue:{value:"false"},description:"",name:"openTitle",required:!1,type:{name:"boolean"}},openActionBar:{defaultValue:{value:"false"},description:"",name:"openActionBar",required:!1,type:{name:"boolean"}}}}}catch{}const k={component:o},a={args:{openTitle:!1,openActionBar:!1,title:{text:"New title"},subtitle:{text:"Subtitle"},actionBar:{text:"Action bar text"},transitionTimes:{fadeIn:500,stay:3500,fadeOut:1e3}}};var f,y,g;a.parameters={...a.parameters,docs:{...(f=a.parameters)==null?void 0:f.docs,source:{originalSource:`{
  args: {
    openTitle: false,
    openActionBar: false,
    title: {
      text: 'New title'
    },
    subtitle: {
      text: 'Subtitle'
    },
    actionBar: {
      text: 'Action bar text'
    },
    transitionTimes: {
      fadeIn: 500,
      stay: 3500,
      fadeOut: 1000
    }
  }
}`,...(g=(y=a.parameters)==null?void 0:y.docs)==null?void 0:g.source}}};const z=["Primary"];export{a as Primary,z as __namedExportsOrder,k as default};
