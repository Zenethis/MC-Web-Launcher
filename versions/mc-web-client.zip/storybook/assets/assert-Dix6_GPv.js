var r,e;function o(){if(e)return r;e=1;function n(s,t){if(!s)throw new Error(t||"unknown assertion error")}return r=n,r}export{o as r};
