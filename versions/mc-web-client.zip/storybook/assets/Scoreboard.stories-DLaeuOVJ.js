import{j as i,a as e}from"./jsx-runtime-BXiUAcbA.js";import{M as s,r as y}from"./MessageFormattedString-29dtJQfm.js";import"./index-yBjzXJbu.js";import"./index-B_ALIsCe.js";import"./index-N2c5PEsY.js";import"./index-fNjTmf9T.js";import"./client-8hqX0wC_.js";import"./errorBoundary-i09yzNIi.js";import"./Button-D8F4WmjU.js";import"./SharedHudVars-BSL9pCCC.js";import"./PixelartIcon-Bmb-JS3z.js";import"./useScrollBehavior-D_95wFNL.js";import"./globalState-CnxBlE5b.js";import"./assert-Dix6_GPv.js";import"./Screen-CUAyKyoP.js";function t({title:o,items:d,open:p,style:u}){return p?i("div",{className:"scoreboard-container",style:u,children:[e("div",{className:"scoreboard-title",children:e(s,{message:o})}),d.map(r=>{const n=r.displayName??r.name;return i("div",{className:"item-container",children:[e("div",{className:"item-name",children:e(s,{message:n})}),e("div",{className:"item-value",children:r.value})]},y(n)+"_"+r.value)})]}):null}try{t.displayName="Scoreboard",t.__docgenInfo={description:"",displayName:"Scoreboard",props:{title:{defaultValue:null,description:"",name:"title",required:!0,type:{name:"string"}},items:{defaultValue:null,description:"",name:"items",required:!0,type:{name:"ScoreboardItems"}},open:{defaultValue:null,description:"",name:"open",required:!0,type:{name:"boolean"}},style:{defaultValue:null,description:"",name:"style",required:!1,type:{name:"CSSProperties"}}}}}catch{}const I={component:t},a={args:{title:"Scoreboard",items:[{name:"item 1",value:9},{name:"item 2",value:8}],open:!0}};var m,l,c;a.parameters={...a.parameters,docs:{...(m=a.parameters)==null?void 0:m.docs,source:{originalSource:`{
  args: {
    title: 'Scoreboard',
    items: [{
      name: 'item 1',
      value: 9
    }, {
      name: 'item 2',
      value: 8
    }],
    open: true
  }
}`,...(c=(l=a.parameters)==null?void 0:l.docs)==null?void 0:c.source}}};const C=["Primary"];export{a as Primary,C as __namedExportsOrder,I as default};
